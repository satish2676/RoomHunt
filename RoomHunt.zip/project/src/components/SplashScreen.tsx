import React from 'react';
import { Loader2 } from 'lucide-react';

const SplashScreen: React.FC = () => {
  return (
    <div className="flex items-center justify-center h-screen bg-gradient-to-br from-teal-600 via-teal-700 to-blue-800 text-white">
      <div className="flex flex-col items-center space-y-4">
        {/* Logo */}
        <img src="/IMG_20250603_135050.jpg" alt="App Logo" className="w-20 h-20" />

        {/* Welcome Message */}
        <h2 className="text-2xl font-bold animate-pulse">Welcome to RoomHunt</h2>

        {/* Spinner */}
        <Loader2 className="animate-spin" size={36} />

        {/* Optional tagline */}
        <p className="text-sm text-teal-100 italic">Finding your perfect room just got easier</p>
      </div>
    </div>
  );
};

export default SplashScreen;
