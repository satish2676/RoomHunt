import React from 'react';
import { MapPin } from 'lucide-react';
import { motion } from 'framer-motion';

const PopularAreas: React.FC = () => {
  const areas = [
    { 
      name: 'Ameerpet', 
     
      image: 'https://images.pexels.com/photos/2102587/pexels-photo-2102587.jpeg?auto=compress&cs=tinysrgb&w=400',
      description: 'IT Hub & Commercial Center'
    },
    { 
      name: 'Kukatpally', 
    
      image: 'https://images.pexels.com/photos/1643383/pexels-photo-1643383.jpeg?auto=compress&cs=tinysrgb&w=400',
      description: 'Residential & Shopping Hub'
    },
    { 
      name: 'Madhapur', 
    
      image: 'https://images.pexels.com/photos/1370704/pexels-photo-1370704.jpeg?auto=compress&cs=tinysrgb&w=400',
      description: 'HITEC City & Financial District'
    },
    { 
      name: 'Gachibowli', 
       
      image: 'https://images.pexels.com/photos/2102587/pexels-photo-2102587.jpeg?auto=compress&cs=tinysrgb&w=400',
      description: 'IT Corridor & Modern Living'
    },
    { 
      name: 'Hitech City', 
      
      image: 'https://images.pexels.com/photos/1643383/pexels-photo-1643383.jpeg?auto=compress&cs=tinysrgb&w=400',
      description: 'Technology & Business Hub'
    },
    { 
      name: 'Kondapur', 
     
      image: 'https://images.pexels.com/photos/1370704/pexels-photo-1370704.jpeg?auto=compress&cs=tinysrgb&w=400',
      description: 'Emerging IT Destination'
    }
  ];

  return (
    <section className="py-12 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-10">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Popular Areas in Hyderabad</h2>
          <p className="text-gray-600 text-lg">Discover the best neighborhoods for your next home</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {areas.map((area, index) => (
            <motion.div
              key={area.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ y: -8, scale: 1.02 }}
              className="bg-white rounded-xl shadow-lg overflow-hidden cursor-pointer hover:shadow-xl transition-all duration-300"
            >
              <div className="relative h-48 overflow-hidden">
                <img
                  src={area.image}
                  alt={`${area.name} area in Hyderabad`}
                  className="w-full h-full object-cover transition-transform duration-300 hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent" />
                <div className="absolute bottom-4 left-4 text-white">
                  <div className="flex items-center space-x-2 mb-2">
                   
                    
                  </div>
                  <h3 className="text-xl font-bold">{area.name}</h3>
                  <p className="text-sm text-gray-200">{area.description}</p>
                </div>
              </div>
              
              <div className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-semibold text-gray-900">{area.name}</h4>
                    <p className="text-sm text-gray-600">{area.description}</p>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-teal-600">{area.count}</div>
                   
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
        
      </div>
    </section>
  );
};

export default PopularAreas;