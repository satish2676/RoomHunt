import React, { useState } from 'react';
import { Search, MapPin, Home } from 'lucide-react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';

const Hero: React.FC = () => {
  const [searchText, setSearchText] = useState('');
  const navigate = useNavigate();

  const handleSearch = () => {
    if (searchText.trim()) {
      navigate(`/accommodations?search=${encodeURIComponent(searchText.trim())}`);
    }
  };

  return (
    <section className="bg-gradient-to-br from-teal-600 via-teal-700 to-blue-800 text-white py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Find Your Perfect <span className="block text-yellow-300">Room in Hyderabad</span>
            </h1>
            <p className="text-xl md:text-2xl text-teal-100 mb-8 max-w-3xl mx-auto">
              Discover thousands of rental rooms and PGs with no broker fees. Connect directly with property owners.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-6 mb-12"
          >
            <div className="flex items-center space-x-2 bg-white bg-opacity-20 rounded-full px-6 py-3">
              <Home size={20} />
              <span>5000+ Properties</span>
            </div>
            <div className="flex items-center space-x-2 bg-white bg-opacity-20 rounded-full px-6 py-3">
              <MapPin size={20} />
              <span>50+ Areas</span>
            </div>
            <div className="flex items-center space-x-2 bg-white bg-opacity-20 rounded-full px-6 py-3">
              <Search size={20} />
              <span>No Broker Fee</span>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="max-w-2xl mx-auto"
          >
            <div className="bg-white rounded-2xl p-2 shadow-xl">
              <div className="flex flex-col sm:flex-row">
                <div className="flex-1 relative">
                  <MapPin size={20} className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Search by area (e.g., Ameerpet, Kukatpally)"
                    value={searchText}
                    onChange={(e) => setSearchText(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                    className="w-full pl-12 pr-4 py-4 text-gray-900 rounded-xl sm:rounded-r-none focus:outline-none focus:ring-2 focus:ring-teal-500"
                  />
                </div>
                <motion.button
                  whileTap={{ scale: 0.95 }}
                  onClick={handleSearch}
                  className="bg-teal-600 text-white px-8 py-4 rounded-xl sm:rounded-l-none hover:bg-teal-700 transition-colors font-medium flex items-center justify-center space-x-2"
                >
                  <Search size={20} />
                  <span>Search</span>
                </motion.button>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
