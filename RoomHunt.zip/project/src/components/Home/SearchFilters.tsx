import React, { useState } from 'react';
import { Search, Filter, MapPin, Home, Users } from 'lucide-react';
import { motion } from 'framer-motion';

interface SearchFiltersProps {
  onSearch: (filters: any) => void;
}

const SearchFilters: React.FC<SearchFiltersProps> = ({ onSearch }) => {
  const [filters, setFilters] = useState({
    location: '',
    roomType: '',
    priceRange: '',
    allowedFor: '',
    furnishing: '',
    isAvailable: 'true' // default: show only available properties
  });
  const [showAdvanced, setShowAdvanced] = useState(false);

  const handleFilterChange = (key: string, value: string) => {
    const newFilters = { ...filters, [key]: value };
    setFilters(newFilters);
    onSearch(newFilters);
  };

  const clearFilters = () => {
    const emptyFilters = {
      location: '',
      roomType: '',
      priceRange: '',
      allowedFor: '',
      furnishing: '',
      isAvailable: 'true'
    };
    setFilters(emptyFilters);
    onSearch(emptyFilters);
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-900 flex items-center">
          <Search size={20} className="mr-2" />
          Find Your Perfect Room
        </h3>
        <button
          onClick={() => setShowAdvanced(!showAdvanced)}
          className="flex items-center space-x-2 text-teal-600 hover:text-teal-700"
        >
          <Filter size={16} />
          <span className="text-sm">Advanced</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-4">
        {/* Location */}
        <div className="relative">
          <MapPin size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder="Search by location..."
            value={filters.location}
            onChange={(e) => handleFilterChange('location', e.target.value)}
            className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent"
          />
        </div>

        {/* Room Type */}
        <div className="relative">
          <Home size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          <select
            value={filters.roomType}
            onChange={(e) => handleFilterChange('roomType', e.target.value)}
            className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent appearance-none"
          >
            <option value="">All Types</option>
            <option value="Room">Room</option>
            <option value="PG">PG</option>
          </select>
        </div>

        {/* Price Range */}
        <div>
          <select
            value={filters.priceRange}
            onChange={(e) => handleFilterChange('priceRange', e.target.value)}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent"
          >
            <option value="">Any Price</option>
            <option value="0-10000">Under ₹10,000</option>
            <option value="10000-20000">₹10,000 - ₹20,000</option>
            <option value="20000-30000">₹20,000 - ₹30,000</option>
            <option value="30000-50000">₹30,000 - ₹50,000</option>
            <option value="50000+">Above ₹50,000</option>
          </select>
        </div>
      </div>

      {/* Advanced Filters */}
      <motion.div
        initial={false}
        animate={{ height: showAdvanced ? 'auto' : 0, opacity: showAdvanced ? 1 : 0 }}
        className="overflow-hidden"
      >
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t border-gray-200">
          {/* Allowed For */}
          <div className="relative">
            <Users size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <select
              value={filters.allowedFor}
              onChange={(e) => handleFilterChange('allowedFor', e.target.value)}
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent appearance-none"
            >
              <option value="">Anyone</option>
              <option value="Family">Family Only</option>
              <option value="Bachelors">Bachelors Only</option>
              <option value="Both">Both</option>
            </select>
          </div>

          {/* Furnishing */}
          <div>
            <select
              value={filters.furnishing}
              onChange={(e) => handleFilterChange('furnishing', e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent"
            >
              <option value="">Any Furnishing</option>
              <option value="Furnished">Furnished</option>
              <option value="Semi-Furnished">Semi-Furnished</option>
              <option value="Unfurnished">Unfurnished</option>
            </select>
          </div>
        </div>

        {/* Show Only Available Toggle */}
        <div className="pt-4">
          <div className="flex items-center space-x-2">
            <input
              type="checkbox"
              id="availableOnly"
              checked={filters.isAvailable === 'true'}
              onChange={(e) => handleFilterChange('isAvailable', e.target.checked ? 'true' : '')}
              className="form-checkbox text-teal-600"
            />
            <label htmlFor="availableOnly" className="text-sm text-gray-700">
              Show Only Available
            </label>
          </div>
        </div>
      </motion.div>

      {/* Clear Filters */}
      <div className="flex justify-end mt-4">
        <button
          onClick={clearFilters}
          className="text-sm text-gray-600 hover:text-gray-800 underline"
        >
          Clear all filters
        </button>
      </div>
    </div>
  );
};

export default SearchFilters;
``
