import React from 'react';
import { Home, Plus, Building2, User, Heart } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';

const Footer: React.FC = () => {
  const { currentUser, userType } = useAuth();
  const navigate = useNavigate();

  const handleAddRoom = () => {
    if (!currentUser) {
      alert('You must log in to post a property');
      return;
    }
    if (userType !== 'owner') {
      alert('Only property owners can post properties');
      return;
    }
    navigate('/add-property');
  };

  const handleNavigation = (href: string) => {
    navigate(href);
  };

  const tabs = [
    { icon: Home, label: 'Home', href: '/', active: window.location.pathname === '/' },
    { icon: Plus, label: 'Add Room', onClick: handleAddRoom },
    { icon: Building2, label: 'Rooms', href: '/accommodations', active: window.location.pathname === '/accommodations' || window.location.pathname === '/pgs' },
    { icon: Heart, label: 'Favorites', href: '/favorites', active: window.location.pathname === '/favorites' },
    { icon: User, label: 'Profile', href: '/profile', active: window.location.pathname === '/profile' }
  ];

  return (
    <footer className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-30">
      <div className="flex justify-around items-center py-2">
        {tabs.map((tab, index) => (
          <motion.button
            key={index}
            whileTap={{ scale: 0.95 }}
            onClick={tab.onClick || (() => handleNavigation(tab.href || '/'))}
            className={`flex flex-col items-center p-2 rounded-lg transition-colors ${
              tab.active ? 'text-teal-600' : 'text-gray-500 hover:text-teal-600'
            }`}
          >
            <tab.icon size={20} />
            <span className="text-xs mt-1">{tab.label}</span>
          </motion.button>
        ))}
      </div>
    </footer>
  );
};

export default Footer;