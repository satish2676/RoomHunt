import React, { useState } from 'react';
import { Menu, X, Home, User, LogOut, Building2, Heart } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { currentUser, signOut, userType } = useAuth();
  const navigate = useNavigate();

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);

  const handleLogout = async () => {
    try {
      await signOut();
      setIsMenuOpen(false);
      navigate('/');
    } catch (error) {
      console.error('Failed to logout:', error);
    }
  };

  const handleNavigation = (href: string) => {
    setIsMenuOpen(false);
    navigate(href);
  };

  return (
    <>
      <header className="bg-white shadow-lg sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <button
              onClick={() => navigate('/')}
              className="flex items-center space-x-3"
            >
              <img 
                src="/IMG_20250603_135050.jpg" 
                alt="RoomHunt Logo" 
                className="h-10 w-10 rounded-lg"
              />
              <h1 className="text-2xl font-bold text-teal-600">RoomHunt</h1>
            </button>
            
            <button
              onClick={toggleMenu}
              className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </header>

      <AnimatePresence>
        {isMenuOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black bg-opacity-50 z-50"
              onClick={() => setIsMenuOpen(false)}
            />
            <motion.div
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'tween', duration: 0.3 }}
              className="fixed left-0 top-0 h-full w-80 bg-white shadow-xl z-50 overflow-y-auto"
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-8">
                  <div className="flex items-center space-x-3">
                    <img 
                      src="/IMG_20250603_135050.jpg" 
                      alt="RoomHunt Logo" 
                      className="h-10 w-10 rounded-lg"
                    />
                    <h2 className="text-xl font-bold text-teal-600">RoomHunt</h2>
                  </div>
                  <button
                    onClick={() => setIsMenuOpen(false)}
                    className="p-2 rounded-lg hover:bg-gray-100"
                  >
                    <X size={20} />
                  </button>
                </div>

                {currentUser && (
                  <div className="mb-6 p-4 bg-teal-50 rounded-lg">
                    <p className="font-medium text-gray-900">{currentUser.email}</p>
                    <p className="text-sm text-teal-600 capitalize">{userType} Account</p>
                  </div>
                )}

                <nav className="space-y-2">
                  <button
                    onClick={() => handleNavigation('/')}
                    className="flex items-center space-x-3 p-3 rounded-lg hover:bg-gray-100 transition-colors w-full text-left"
                  >
                    <Home size={20} />
                    <span>Home</span>
                  </button>

                  <button
                    onClick={() => handleNavigation('/favorites')}
                    className="flex items-center space-x-3 p-3 rounded-lg hover:bg-gray-100 transition-colors w-full text-left"
                  >
                    <Heart size={20} />
                    <span>Favorites</span>
                  </button>

                  {currentUser && userType === 'owner' && (
                    <button
                      onClick={() => handleNavigation('/my-properties')}
                      className="flex items-center space-x-3 p-3 rounded-lg hover:bg-gray-100 transition-colors w-full text-left"
                    >
                      <Building2 size={20} />
                      <span>My Properties</span>
                    </button>
                  )}

                  <button
                    onClick={() => handleNavigation('/premium')}
                    className="flex items-center space-x-3 p-3 rounded-lg hover:bg-gray-100 transition-colors w-full text-left"
                  >
                    <User size={20} />
                    <span>Premium Access</span>
                  </button>

                  {currentUser ? (
                    <>
                      <button
                        onClick={() => handleNavigation('/profile')}
                        className="flex items-center space-x-3 p-3 rounded-lg hover:bg-gray-100 transition-colors w-full text-left"
                      >
                        <User size={20} />
                        <span>Profile</span>
                      </button>
                      <button
                        onClick={handleLogout}
                        className="flex items-center space-x-3 p-3 rounded-lg hover:bg-gray-100 transition-colors w-full text-left text-red-600"
                      >
                        <LogOut size={20} />
                        <span>Logout</span>
                      </button>
                    </>
                  ) : (
                    <button
                      onClick={() => handleNavigation('/login')}
                      className="flex items-center space-x-3 p-3 rounded-lg hover:bg-gray-100 transition-colors w-full text-left"
                    >
                      <User size={20} />
                      <span>Login</span>
                    </button>
                  )}
                </nav>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
};

export default Header;