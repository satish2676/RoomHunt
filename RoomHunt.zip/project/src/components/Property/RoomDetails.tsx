import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { supabase } from '../../lib/supabase';
import {
  MapPin, User2, Phone, Play, Gift, Loader2
} from 'lucide-react';
import { motion } from 'framer-motion';
import { useAuth } from '../../contexts/AuthContext';
import { adMobService } from '../../lib/admob';

const RoomDetails: React.FC = () => {
  const { id } = useParams();
  const [room, setRoom] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [showContactModal, setShowContactModal] = useState(false);
  const [adLoading, setAdLoading] = useState(false);
  const [adError, setAdError] = useState<string | null>(null);

  const { currentUser, isPremium, updatePremiumStatus } = useAuth();

  useEffect(() => {
    const fetchRoom = async () => {
      const { data, error } = await supabase
        .from('rooms')
        .select('*')
        .eq('id', id)
        .single();

      if (!error) setRoom(data);
      setLoading(false);
    };

    fetchRoom();
    // Preload ads for better user experience
    adMobService.preloadRewardedAd().catch(console.error);
  }, [id]);

  const handleViewContact = () => {
    setShowContactModal(true);
    setAdError(null);
  };

  const handleWatchAd = async () => {
    if (!currentUser) {
      alert('Please login to view contact details');
      return;
    }

    setAdLoading(true);
    setAdError(null);

    try {
      const adWatched = await adMobService.showRewardedAd();
      
      if (adWatched) {
        // Update premium status in database
        await updatePremiumStatus(true);
        
        // Show success message
        const successMessage = document.createElement('div');
        successMessage.className = 'fixed top-4 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50';
        successMessage.textContent = '🎉 Contact unlocked! You now have premium access.';
        document.body.appendChild(successMessage);
        
        setTimeout(() => {
          document.body.removeChild(successMessage);
        }, 3000);
      } else {
        setAdError('Please watch the complete ad to unlock contact details.');
      }
    } catch (error) {
      console.error('Error showing ad:', error);
      setAdError('Ad not available now. Try again later.');
    } finally {
      setAdLoading(false);
    }
  };

  if (loading) return <p className="text-center mt-8">Loading...</p>;
  if (!room) return <p className="text-center mt-8">Room not found.</p>;

  const images = room.image_urls || [room.image_url];

  return (
    <div className="max-w-7xl mx-auto p-6 mt-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:justify-between mb-6">
        <div>
          <h1 className="text-3xl font-semibold text-gray-800">{room.title}</h1>
          <p className="text-sm text-gray-500 flex items-center gap-1">
            <p className="text-sm text-yellow-600 font-medium mt-1">Location : </p>
            <a
              href= {`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(room.location)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1 text-blue-600 hover:underline"
              title="Open in Google Maps"
            >
              <MapPin size={16} />
              {room.location}
            </a>
          </p>
          <p className="text-sm text-yellow-600 font-medium mt-1">⭐ 4.5 (1.5k Reviews)</p>
        </div>
        <div className="text-right mt-4 md:mt-0">
          <p className="text-xl font-semibold text-gray-800">₹{room.rent}/month</p>
          <p className="text-xl font-semibold text-gray-800">🔐 Deposit: ₹{room.security_deposit}</p>
          <p className="text-sm text-gray-500">Check-in: {room.available_from || 'N/A'}</p>
        </div>
      </div>

      {/* Image Gallery */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <img src={images[0]} alt="Main" className="w-full h-72 object-cover rounded-xl" />
        <div className="grid grid-cols-2 gap-2">
          {images.slice(1, 5).map((img: string, index: number) => (
            <img
              key={index}
              src={img}
              alt={`Gallery ${index}`}
              className="w-full h-32 object-cover rounded-xl"
            />
          ))}
        </div>
      </div>

      {/* Overview */}
      <div className="mb-8">
        <h2 className="text-xl font-semibold mb-3">About this space</h2>
        <p className="text-gray-700 leading-relaxed">{room.description}</p>
      </div>

      {/* Feature Cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-8">
        <div className="bg-gray-100 rounded-xl p-4 text-center font-semibold">🛏 {room.bedrooms} Bedrooms</div>
        <div className="bg-gray-100 rounded-xl p-4 text-center font-semibold">🛁 {room.bathrooms} Bathrooms</div>
        <div className="bg-gray-100 rounded-xl p-4 text-center font-semibold">📐 {room.area_sqft} Sqft</div>
        <div className="bg-gray-100 rounded-xl p-4 text-center font-semibold">🏢 Floor {room.floor_number}/{room.total_floors}</div>
        <div className="bg-gray-100 rounded-xl p-4 text-center font-semibold">🛋 {room.furnishing_type}</div>
      </div>

      {/* Amenities */}
      <div className="mb-8">
        <h2 className="text-xl font-semibold mb-2">Amenities</h2>
        <ul className="flex flex-wrap gap-2 text-sm text-gray-700">
          {(room.amenities || []).map((item: string, index: number) => (
            <li key={index} className="px-3 py-1 bg-blue-100 rounded-full">{item}</li>
          ))}
        </ul>
      </div>

      {/* Rules & Preferences */}
      <div className="mb-8">
        <h2 className="text-xl font-semibold mb-2">House Rules & Preferences</h2>
        <p className="text-sm mb-1"><strong>Min Stay:</strong> {room.minimum_stay_months} months</p>
        <p className="text-sm mb-1"><strong>Age Limit:</strong> {room.min_age}-{room.max_age} yrs</p>
        <p className="text-sm mb-1"><strong>Preferred:</strong> {room.gender_preference}, {room.preferred_professions?.join(', ')}</p>
        <p className="text-sm"><strong>Rules:</strong> {room.house_rules}</p>
      </div>

      {/* Contact Section */}
      <div className="p-6 bg-gray-100 rounded-xl mb-12">
        <h3 className="text-lg font-semibold mb-3">Contact Owner</h3>
        
        {isPremium ? (
          <div className="space-y-3">
            <div className="flex items-center mb-2">
              <Gift className="text-green-600 mr-2" size={20} />
              <span className="text-green-800 font-medium">Premium Access Active</span>
            </div>
            <p className="flex items-center gap-2 text-gray-800">
              <User2 size={16} /> {room.owner_name}
            </p>
            <p className="flex items-center gap-2 text-gray-800">
              <Phone size={16} /> {room.owner_phone}
            </p>
            <a
              href={`tel:${room.owner_phone}`}
              className="inline-block bg-teal-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-teal-700 transition-colors"
            >
              📞 Call Now
            </a>
          </div>
        ) : (
          <div className="text-center">
            <div className="bg-gradient-to-r from-yellow-50 to-orange-50 border border-yellow-200 rounded-lg p-4 mb-4">
              <div className="flex items-center justify-center mb-2">
                <Play className="text-yellow-600 mr-2" size={20} />
                <p className="text-yellow-800 font-medium">Premium Feature</p>
              </div>
              <p className="text-yellow-700 text-sm">
                Watch a short ad to unlock owner contact details and get premium access!
              </p>
            </div>

            <button
              onClick={handleViewContact}
              className="bg-orange-500 text-white px-6 py-3 rounded-lg font-medium hover:bg-orange-600 transition-colors"
            >
              🔓 Unlock Contact Details
            </button>
          </div>
        )}
      </div>

      {/* Contact Modal */}
      {showContactModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-xl p-6 max-w-md w-full"
          >
            <h3 className="text-xl font-bold text-gray-900 mb-4">Contact Owner</h3>
            
            <div className="text-center">
              <div className="bg-gradient-to-r from-yellow-50 to-orange-50 border border-yellow-200 rounded-lg p-4 mb-4">
                <div className="flex items-center justify-center mb-2">
                  <Play className="text-yellow-600 mr-2" size={20} />
                  <p className="text-yellow-800 font-medium">Premium Feature</p>
                </div>
                <p className="text-yellow-700 text-sm">
                  Watch a short ad to unlock owner contact details and get premium access!
                </p>
              </div>

              {adError && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-3 mb-4">
                  <p className="text-red-600 text-sm">{adError}</p>
                </div>
              )}
              
              <button
                onClick={handleWatchAd}
                disabled={adLoading}
                className="w-full bg-gradient-to-r from-green-500 to-green-600 text-white py-3 px-4 rounded-lg font-medium hover:from-green-600 hover:to-green-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center justify-center"
              >
                {adLoading ? (
                  <>
                    <Loader2 className="animate-spin mr-2" size={16} />
                    Loading Ad...
                  </>
                ) : (
                  <>
                    <Play className="mr-2" size={16} />
                    Watch Ad & Unlock Contact
                  </>
                )}
              </button>

              <p className="text-xs text-gray-500 mt-2">
                Free • 30 seconds • Unlocks premium access
              </p>
            </div>
            
            <button
              onClick={() => {
                setShowContactModal(false);
                setAdError(null);
              }}
              className="w-full mt-4 bg-gray-100 text-gray-700 py-2 px-4 rounded-lg font-medium hover:bg-gray-200 transition-colors"
            >
              Close
            </button>
          </motion.div>
        </div>
      )}
    </div>
  );
};

export default RoomDetails;