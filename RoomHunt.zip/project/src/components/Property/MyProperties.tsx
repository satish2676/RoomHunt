import React, { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { Pencil } from 'lucide-react';

interface Room {
  id: string;
  title: string;
  rent: number;
  location: string;
  image_urls: string[];
  created_at: string;
  property_type?: string;
  owner_phone?: string;
  description?: string;
  is_available?: boolean;
}

const MyProperties: React.FC = () => {
  const { currentUser } = useAuth();
  const [rooms, setRooms] = useState<Room[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  const fetchMyRooms = async () => {
    if (!currentUser) return;

    const { data, error } = await supabase
      .from('rooms')
      .select('*')
      .eq('owner_id', currentUser.id)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Failed to fetch properties:', error.message);
    } else {
      setRooms(data || []);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchMyRooms();
  }, [currentUser]);

  const toggleAvailability = async (id: string, currentStatus: boolean) => {
    const { error } = await supabase
      .from('rooms')
      .update({ is_available: !currentStatus })
      .eq('id', id);

    if (error) {
      alert('Failed to update availability');
      console.error(error);
      return;
    }

    setRooms(prev =>
      prev.map(room =>
        room.id === id ? { ...room, is_available: !currentStatus } : room
      )
    );
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <p className="text-gray-700 text-lg">Loading your properties...</p>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-6">
      <h2 className="text-2xl font-semibold mb-6">My Listed Properties</h2>
      {rooms.length === 0 ? (
        <p className="text-gray-500">You haven’t listed any properties yet.</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {rooms.map((room) => (
            <div
              key={room.id}
              className="border rounded-lg overflow-hidden hover:shadow-md transition relative bg-white"
            >
              <img
                src={room.image_urls?.[0] ?? '/default.jpg'}
                alt={room.title}
                className="w-full h-48 object-cover"
              />
              <div className="p-4">
                <h3 className="text-lg font-semibold mb-1">{room.title}</h3>
                <p className="text-sm text-gray-600 mb-1">{room.location}</p>
                <p className="text-sm text-gray-600 mb-1">{room.property_type}</p>
                <p className="text-sm text-gray-600 mb-1">{room.description?.slice(0, 50)}...</p>
                <p className="text-sm text-gray-600 mb-1">📞 {room.owner_phone}</p>
                <p className="mt-1 font-bold text-yellow-700">₹{room.rent}/month</p>

                <div className="flex justify-between items-center mt-4">
                  <button
                    onClick={() => navigate(`/edit-property/${room.id}`)}
                    className="flex items-center gap-1 text-blue-600 hover:underline text-sm"
                  >
                    <Pencil size={16} /> Edit
                  </button>

                  
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default MyProperties;
