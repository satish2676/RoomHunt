// components/PropertyModal.tsx
import React from 'react';
import { X } from 'lucide-react';
import { Property } from './PropertyCard'; // or import type if separate

interface PropertyModalProps {
  property: Property;
  onClose: () => void;
}

const PropertyModal: React.FC<PropertyModalProps> = ({ property, onClose }) => {
  return (
    <div className="fixed inset-0 z-50 bg-black bg-opacity-60 flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-2xl rounded-xl shadow-lg overflow-y-auto max-h-[90vh] relative">
        <button
          onClick={onClose}
          className="absolute top-3 right-3 bg-gray-100 hover:bg-gray-200 p-2 rounded-full"
        >
          <X size={20} />
        </button>
        <div className="p-4 space-y-3">
          <h2 className="text-2xl font-semibold">{property.title}</h2>
          <img src={property.image_urls?.[0] || property.image_url || ''} alt={property.title} className="w-full rounded-lg" />
          <p className="text-gray-600"><strong>Rent:</strong> ₹{property.rent.toLocaleString()}/month</p>
          <p><strong>Location:</strong> {property.location}</p>
          <p><strong>Type:</strong> {property.property_type}</p>
          <p><strong>Bedrooms:</strong> {property.bedrooms}</p>
          <p><strong>Bathrooms:</strong> {property.bathrooms}</p>
          <p><strong>Area:</strong> {property.area_sqft} sqft</p>
          <p><strong>Furnishing:</strong> {property.furnishing_type}</p>
          <p><strong>Gender Preference:</strong> {property.gender_preference}</p>
          <p><strong>Amenities:</strong> {property.amenities?.join(', ')}</p>
          <p><strong>Available from:</strong> {property.available_from}</p>
          <p><strong>Owner:</strong> {property.owner_name} ({property.owner_phone})</p>
        </div>
      </div>
    </div>
  );
};

export default PropertyModal;
