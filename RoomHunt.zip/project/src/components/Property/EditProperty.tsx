// src/components/Property/EditProperty.tsx
import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';
import { Loader2 } from 'lucide-react';

interface RoomForm {
  title: string;
  description: string;
  location: string;
  full_address: string;
  city: string;
  pincode: string;
  property_type: string;
  rent: string;
  bedrooms: string;
  bathrooms: string;
  area_sqft: string;
  image_urls: string[];
  amenities: string;
  owner_phone: string;
}

const EditProperty: React.FC = () => {
  const { currentUser } = useAuth();
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  const [form, setForm] = useState<RoomForm>({
    title: '',
    description: '',
    location: '',
    full_address: '',
    city: '',
    pincode: '',
    property_type: '',
    rent: '',
    bedrooms: '',
    bathrooms: '',
    area_sqft: '',
    image_urls: [''],
    amenities: '',
    owner_phone: '',
  });

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!id) return;

    (async () => {
      const { data, error } = await supabase
        .from('rooms')
        .select('*')
        .eq('id', id)
        .single();

      if (error || !data) {
        alert('Failed to load property');
        return navigate('/my-properties');
      }

      if (data.owner_id !== currentUser?.id) {
        alert('Not authorized');
        return navigate('/my-properties');
      }

      setForm({
        title: data.title,
        description: data.description || '',
        location: data.location,
        full_address: data.full_address || '',
        city: data.city || '',
        pincode: data.pincode || '',
        property_type: data.property_type || '',
        rent: String(data.rent),
        bedrooms: String(data.bedrooms || ''),
        bathrooms: String(data.bathrooms || ''),
        area_sqft: String(data.area_sqft || ''),
        image_urls: data.image_urls?.length ? data.image_urls : [''],
        amenities: (data.amenities || []).join(', '),
        owner_phone: data.owner_phone || '',
      });

      setLoading(false);
    })();
  }, [id, navigate, currentUser]);

  const updateField = (k: keyof RoomForm, v: string | string[]) => {
    setForm(s => ({ ...s, [k]: v }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);

    const updates = {
      ...form,
      rent: Number(form.rent),
      bedrooms: Number(form.bedrooms),
      bathrooms: Number(form.bathrooms),
      area_sqft: Number(form.area_sqft),
      image_urls: form.image_urls,
      amenities: form.amenities.split(',').map(a => a.trim()),
    };

    const { error } = await supabase
      .from('rooms')
      .update(updates)
      .eq('id', id);

    setSaving(false);

    if (error) {
      alert('Update failed: ' + error.message);
    } else {
      alert('Updated successfully!');
      navigate('/my-properties');
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Loader2 className="animate-spin text-teal-600" size={40} />
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto p-6 bg-white rounded-lg shadow-lg mt-6">
      <h1 className="text-2xl font-semibold mb-4">Edit Property</h1>
      <form onSubmit={handleSubmit} className="space-y-5">
        {/** Title */}
        <div>
          <label className="block text-sm font-medium">Title</label>
          <input
            name="title"
            type="text"
            value={form.title}
            onChange={e => updateField('title', e.target.value)}
            required
            className="mt-1 block w-full border rounded p-2"
          />
        </div>

        {/** Description */}
        <div>
          <label className="block text-sm font-medium">Description</label>
          <textarea
            name="description"
            value={form.description}
            onChange={e => updateField('description', e.target.value)}
            rows={3}
            className="mt-1 block w-full border rounded p-2"
          />
        </div>

        {/** Basic Fields */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {['location', 'full_address', 'city', 'pincode'].map(field => (
            <div key={field}>
              <label className="block text-sm font-medium">{field.replace('_', ' ')}</label>
              <input
                type="text"
                value={(form as any)[field]}
                onChange={e => updateField(field as any, e.target.value)}
                className="mt-1 block w-full border rounded p-2"
              />
            </div>
          ))}
        </div>

        {/** Property Type & Price */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium">Property Type</label>
            <input
              type="text"
              value={form.property_type}
              onChange={e => updateField('property_type', e.target.value)}
              className="mt-1 block w-full border rounded p-2"
            />
          </div>
          <div>
            <label className="block text-sm font-medium">Rent (₹)</label>
            <input
              type="number"
              value={form.rent}
              onChange={e => updateField('rent', e.target.value)}
              className="mt-1 block w-full border rounded p-2"
              required
            />
          </div>
        </div>

        {/** Details */}
        <div className="grid grid-cols-3 gap-4">
          {['bedrooms', 'bathrooms', 'area_sqft'].map(field => (
            <div key={field}>
              <label className="block text-sm font-medium">{field.replace('_', ' ')}</label>
              <input
                type="number"
                value={(form as any)[field]}
                onChange={e => updateField(field as any, e.target.value)}
                className="mt-1 block w-full border rounded p-2"
              />
            </div>
          ))}
        </div>

        {/** Owner Phone */}
        <div>
          <label className="block text-sm font-medium">Owner Phone</label>
          <input
            type="tel"
            value={form.owner_phone}
            onChange={e => updateField('owner_phone', e.target.value)}
            className="mt-1 block w-full border rounded p-2"
          />
        </div>

        {/** Amenities */}
        <div>
          <label className="block text-sm font-medium">Amenities (comma‑separated)</label>
          <input
            type="text"
            value={form.amenities}
            onChange={e => updateField('amenities', e.target.value)}
            className="mt-1 block w-full border rounded p-2"
          />
        </div>

        {/** Image URLs (up to 3) */}
        <div>
          <label className="block text-sm font-medium">Image URLs</label>
          {form.image_urls.map((url, i) => (
            <input
              key={i}
              type="text"
              value={url}
              onChange={e => {
                const arr = [...form.image_urls];
                arr[i] = e.target.value;
                updateField('image_urls', arr);
              }}
              placeholder={`Image ${i + 1} URL`}
              className="mt-1 block w-full border rounded p-2"
            />
          ))}
          {form.image_urls.length < 3 && (
            <button
              type="button"
              onClick={() => updateField('image_urls', [...form.image_urls, ''])}
              className="mt-2 text-blue-600 hover:underline"
            >
              + Add another image
            </button>
          )}
        </div>

        <button
          type="submit"
          disabled={saving}
          className="w-full bg-teal-600 text-white py-2 rounded hover:bg-teal-700"
        >
          {saving ? 'Saving...' : 'Save Changes'}
        </button>
      </form>
    </div>
  );
};

export default EditProperty;
