import React, { useState } from 'react';
import {
  MapPin, Eye, Heart, Home, Users, Calendar, Wifi,
} from 'lucide-react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { useFavorites } from '../../contexts/FavoritesContext';
import { useAuth } from '../../contexts/AuthContext';

interface Property {
  id: string;
  title: string;
  rent: number;
  location: string;
  image_url: string | null;
  image_urls: string[] | null;
  owner_id: string;
  owner_name: string;
  owner_phone: string;
  is_premium: boolean | null;
  created_at: string | null;
  payment_status: string | null;
  payment_id: string | null;
  property_type?: string | null;
  bedrooms?: number;
  bathrooms?: number;
  area_sqft?: number;
  furnishing_type?: string;
  amenities?: string[];
  available_from?: string;
  gender_preference?: string;
}

interface PropertyCardProps {
  property: Property;
  onViewContact?: (property: Property) => void;
}

const PropertyCard: React.FC<PropertyCardProps> = ({ property, onViewContact }) => {
  const { addToFavorites, removeFromFavorites, isFavorite } = useFavorites();
  const { currentUser } = useAuth();
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  const handleFavoriteToggle = async () => {
    if (!currentUser) {
      alert('Please login to add favorites');
      return;
    }

    try {
      if (isFavorite(property.id)) {
        await removeFromFavorites(property.id);
      } else {
        await addToFavorites(property.id);
      }
    } catch (error) {
      console.error('Error toggling favorite:', error);
    }
  };

  const handleContactClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (onViewContact) {
      onViewContact(property);
    }
  };

  const getDisplayImage = () => {
    if (property.image_urls && property.image_urls.length > 0) {
      return property.image_urls[currentImageIndex] || property.image_urls[0];
    }
    return property.image_url;
  };

  const nextImage = () => {
    if (property.image_urls && property.image_urls.length > 1) {
      setCurrentImageIndex((prev) => (prev === property.image_urls!.length - 1 ? 0 : prev + 1));
    }
  };

  const prevImage = () => {
    if (property.image_urls && property.image_urls.length > 1) {
      setCurrentImageIndex((prev) => (prev === 0 ? property.image_urls!.length - 1 : prev - 1));
    }
  };

  const displayImage = getDisplayImage();
  const imageCount = property.image_urls?.length || (property.image_url ? 1 : 0);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -5 }}
      className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300"
    >
      {/* Image Section */}
      <div className="relative h-48 overflow-hidden group cursor-pointer">
        {displayImage ? (
          <>
            <img
              src={displayImage}
              alt={property.title}
              className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
            />
            {imageCount > 1 && (
              <>
                <button
                  onClick={(e) => { e.stopPropagation(); prevImage(); }}
                  className="absolute left-2 top-1/2 transform -translate-y-1/2 bg-black bg-opacity-50 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                >←</button>
                <button
                  onClick={(e) => { e.stopPropagation(); nextImage(); }}
                  className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-black bg-opacity-50 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                >→</button>
                <div className="absolute bottom-2 right-2 bg-black bg-opacity-50 text-white px-2 py-1 rounded-full text-xs">
                  {currentImageIndex + 1}/{imageCount}
                </div>
              </>
            )}
          </>
        ) : (
          <div className="w-full h-full bg-gray-200 flex items-center justify-center">
            <div className="text-gray-400 text-center">
              <div className="text-4xl mb-2">🏠</div>
              <div className="text-sm">No Image</div>
            </div>
          </div>
        )}

        <div className="absolute top-2 left-2 flex space-x-2">
          {property.property_type && (
            <span className="bg-teal-600 text-white px-2 py-1 rounded-full text-xs font-medium">
              {property.property_type}
            </span>
          )}
          {property.is_premium && (
            <span className="bg-yellow-500 text-white px-2 py-1 rounded-full text-xs font-medium">
              Premium
            </span>
          )}
        </div>

        <div className="absolute top-2 right-2 flex space-x-2">
          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={(e) => { e.stopPropagation(); handleFavoriteToggle(); }}
            className={`p-2 rounded-full ${
              isFavorite(property.id)
                ? 'bg-red-500 text-white'
                : 'bg-white bg-opacity-80 text-gray-600 hover:text-red-500'
            } transition-colors`}
          >
            <Heart size={16} fill={isFavorite(property.id) ? 'currentColor' : 'none'} />
          </motion.button>
        </div>
      </div>

      {/* Info Section */}
      <div className="p-4">
        <h3 className="text-lg font-semibold text-gray-900 mb-2 line-clamp-2">{property.title}</h3>
        <div className="flex items-center text-gray-600 mb-3">
          <MapPin size={16} className="mr-1 flex-shrink-0" />
          <span className="text-sm truncate">{property.location}</span>
        </div>

        <div className="grid grid-cols-2 gap-2 mb-3 text-xs text-gray-600">
          {property.bedrooms && <div className="flex items-center"><Home size={12} className="mr-1" /><span>{property.bedrooms} BHK</span></div>}
          {property.area_sqft && <div className="flex items-center"><span>{property.area_sqft} sq ft</span></div>}
          {property.furnishing_type && <div className="flex items-center"><span>{property.furnishing_type}</span></div>}
          {property.gender_preference && property.gender_preference !== 'Any' && (
            <div className="flex items-center"><Users size={12} className="mr-1" /><span>{property.gender_preference}</span></div>
          )}
        </div>

        {property.amenities && property.amenities.length > 0 && (
          <div className="mb-3">
            <div className="flex flex-wrap gap-1">
              {property.amenities.slice(0, 3).map((amenity, index) => (
                <span key={index} className="bg-gray-100 text-gray-600 px-2 py-1 rounded-full text-xs">
                  {amenity === 'WiFi' && <Wifi size={10} className="inline mr-1" />}
                  {amenity}
                </span>
              ))}
              {property.amenities.length > 3 && (
                <span className="bg-gray-100 text-gray-600 px-2 py-1 rounded-full text-xs">
                  +{property.amenities.length - 3} more
                </span>
              )}
            </div>
          </div>
        )}

        {property.available_from && (
          <div className="flex items-center text-gray-600 mb-3">
            <Calendar size={12} className="mr-1" />
            <span className="text-xs">Available from {new Date(property.available_from).toLocaleDateString()}</span>
          </div>
        )}

        <div className="flex items-center justify-between mb-4">
          <div>
            <span className="text-2xl font-bold text-teal-600">₹{property.rent.toLocaleString()}</span>
            <span className="text-gray-500 text-sm">/month</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-2">
          <Link
            to={`/rooms/${property.id}`}
            onClick={(e) => e.stopPropagation()}
            className="w-full"
          >
            <button className="w-full bg-teal-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-teal-700 transition-colors flex items-center justify-center">
              <Eye size={16} className="mr-1" />
              Show Details
            </button>
          </Link>

          {onViewContact && (
            <button 
              onClick={handleContactClick}
              className="w-full bg-orange-500 text-white py-2 px-4 rounded-lg font-medium hover:bg-orange-600 transition-colors flex items-center justify-center"
            >
              📞 View Contact
            </button>
          )}
        </div>
      </div>
    </motion.div>
  );
};

export default PropertyCard;