import React, { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import { Loader2 } from 'lucide-react';

interface Property {
  id: number;
  title: string;
  area: string;
  owner_name: string;
  price?: number;
  image_url?: string;
  [key: string]: any;
}

const SearchFilters: React.FC = () => {
  const [allProperties, setAllProperties] = useState<Property[]>([]);
  const [filtered, setFiltered] = useState<Property[]>([]);
  const [loading, setLoading] = useState(true);
  
  const [searchTitle, setSearchTitle] = useState('');
  const [searchArea, setSearchArea] = useState('');
  const [searchOwner, setSearchOwner] = useState('');

  useEffect(() => {
    const load = async () => {
      const { data, error } = await supabase
        .from('properties')
        .select('id, title, area, owner_name, price, image_url');
      if (error) console.error('Error loading properties:', error);
      setAllProperties(data || []);
      setFiltered(data || []);
      setLoading(false);
    };
    load();
  }, []);

  useEffect(() => {
    const f = allProperties.filter(p => {
      return (
        (!searchTitle || p.title.toLowerCase().includes(searchTitle.toLowerCase())) &&
        (!searchArea || p.area.toLowerCase().includes(searchArea.toLowerCase())) &&
        (!searchOwner || p.owner_name.toLowerCase().includes(searchOwner.toLowerCase()))
      );
    });
    setFiltered(f);
  }, [searchTitle, searchArea, searchOwner, allProperties]);

  if (loading) {
    return (
      <div className="flex justify-center py-6">
        <Loader2 className="animate-spin text-teal-600" size={28} />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <input
          type="text"
          placeholder="Search by title..."
          value={searchTitle}
          onChange={e => setSearchTitle(e.target.value)}
          className="p-2 border rounded"
        />
        <input
          type="text"
          placeholder="Search by area..."
          value={searchArea}
          onChange={e => setSearchArea(e.target.value)}
          className="p-2 border rounded"
        />
        <input
          type="text"
          placeholder="Search by owner..."
          value={searchOwner}
          onChange={e => setSearchOwner(e.target.value)}
          className="p-2 border rounded"
        />
      </div>

      {filtered.length === 0 ? (
        <p className="text-center text-gray-500 mt-6">No Results Found</p>
      ) : (
        <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-4">
          {filtered.map(p => (
            <div key={p.id} className="border rounded shadow-sm overflow-hidden">
              {p.image_url ? (
                <img src={p.image_url} alt={p.title} className="h-40 w-full object-cover" />
              ) : (
                <div className="h-40 bg-gray-200 flex items-center justify-center text-gray-400">
                  No Image
                </div>
              )}
              <div className="p-2">
                <h3 className="font-semibold">{p.title}</h3>
                <p className="text-sm text-gray-600">{p.area}</p>
                <p className="text-sm text-gray-500">By {p.owner_name}</p>
                {p.price != null && (
                  <p className="text-teal-600 font-medium mt-1">₹{p.price}</p>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default SearchFilters;
