import React, { useEffect, useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import { FavoritesProvider } from './contexts/FavoritesContext';
import Header from './components/Layout/Header';
import Footer from './components/Layout/Footer';
import Home from './pages/Home';
import Login from './components/Auth/Login';
import Register from './components/Auth/Register';
import AddProperty from './components/Property/AddProperty';
import Profile from './pages/Profile';
import Favorites from './pages/Favorites';
import Accommodations from './pages/Accommodations';
import MyProperties from './components/Property/MyProperties';
import EditProperty from './components/Property/EditProperty';
import RoomDetails from './components/Property/RoomDetails';
import SplashScreen from './components/SplashScreen'; // ✅ Import splash screen

function App() {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const timeout = setTimeout(() => {
      setIsLoading(false);
    }, 1500); // Show splash for 1.5 seconds

    return () => clearTimeout(timeout);
  }, []);

  return (
    <AuthProvider>
      <FavoritesProvider>
        <Router>
          <div className="min-h-screen bg-gray-50">
            {isLoading ? (
              <SplashScreen />
            ) : (
              <>
                <Header />

                <main className="pb-20">
                  <Routes>
                    <Route path="/" element={<Home />} />
                    <Route path="/login" element={<Login />} />
                    <Route path="/register" element={<Register />} />
                    <Route path="/add-property" element={<AddProperty />} />
                    <Route path="/accommodations" element={<Accommodations />} />
                    <Route path="/pgs" element={<Accommodations />} />
                    <Route path="/profile" element={<Profile />} />
                    <Route path="/favorites" element={<Favorites />} />
                    <Route path="/premium" element={<div className="p-8 text-center">Premium features coming soon!</div>} />
                    <Route path="/my-properties" element={<MyProperties />} />
                    <Route path="/edit-property/:id" element={<EditProperty />} />
                    <Route path="/rooms/:id" element={<RoomDetails />} />
                  </Routes>
                </main>

                <Footer />
              </>
            )}
          </div>
        </Router>
      </FavoritesProvider>
    </AuthProvider>
  );
}

export default App;
