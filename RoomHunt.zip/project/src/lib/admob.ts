import { AdMob, AdOptions, RewardedAdOptions } from '@capacitor-community/admob';
import { Capacitor } from '@capacitor/core';

export interface AdReward {
  type: string;
  amount: number;
}

export class AdMobService {
  private static instance: AdMobService;
  private isInitialized = false;

  private constructor() {}

  static getInstance(): AdMobService {
    if (!AdMobService.instance) {
      AdMobService.instance = new AdMobService();
    }
    return AdMobService.instance;
  }

  async initialize(): Promise<void> {
    if (this.isInitialized) return;

    // Skip AdMob initialization on web platform
    if (!Capacitor.isNativePlatform()) {
      console.log('AdMob not available on web platform - using mock implementation');
      this.isInitialized = true;
      return;
    }

    try {
      await AdMob.initialize({
        requestTrackingAuthorization: true,
        testingDevices: ['YOUR_DEVICE_ID'], // Add your test device ID
        initializeForTesting: true,
      });
      this.isInitialized = true;
      console.log('AdMob initialized successfully');
    } catch (error) {
      console.error('Failed to initialize AdMob:', error);
      throw error;
    }
  }

  private showMockAd(): Promise<boolean> {
    return new Promise((resolve) => {
      // Create mock ad overlay
      const adOverlay = document.createElement('div');
      adOverlay.className = 'fixed inset-0 bg-black bg-opacity-90 flex items-center justify-center z-[9999]';
      adOverlay.innerHTML = `
        <div class="bg-white rounded-xl p-8 max-w-md w-full mx-4 text-center">
          <div class="mb-4">
            <div class="w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg class="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 20 20">
                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clip-rule="evenodd"></path>
              </svg>
            </div>
            <h3 class="text-xl font-bold text-gray-900 mb-2">Watch Ad to Continue</h3>
            <p class="text-gray-600 text-sm mb-4">This is a demo ad. In the real app, you would see a video advertisement here.</p>
          </div>
          
          <div class="bg-gray-100 rounded-lg p-4 mb-4">
            <div class="flex items-center justify-center mb-2">
              <div class="w-4 h-4 bg-blue-500 rounded-full animate-pulse mr-2"></div>
              <span class="text-sm font-medium">Ad playing...</span>
            </div>
            <div class="w-full bg-gray-200 rounded-full h-2">
              <div id="ad-progress" class="bg-blue-500 h-2 rounded-full transition-all duration-1000" style="width: 0%"></div>
            </div>
            <p class="text-xs text-gray-500 mt-2">
              <span id="ad-timer">5</span> seconds remaining
            </p>
          </div>
          
          <button 
            id="close-ad-btn" 
            class="w-full bg-gray-300 text-gray-500 py-2 px-4 rounded-lg font-medium cursor-not-allowed"
            disabled
          >
            Close Ad (wait <span id="close-timer">5</span>s)
          </button>
        </div>
      `;

      document.body.appendChild(adOverlay);

      let timeLeft = 5;
      const progressBar = adOverlay.querySelector('#ad-progress') as HTMLElement;
      const timerElement = adOverlay.querySelector('#ad-timer') as HTMLElement;
      const closeBtn = adOverlay.querySelector('#close-ad-btn') as HTMLButtonElement;
      const closeTimer = adOverlay.querySelector('#close-timer') as HTMLElement;

      const interval = setInterval(() => {
        timeLeft--;
        const progress = ((5 - timeLeft) / 5) * 100;
        
        if (progressBar) progressBar.style.width = `${progress}%`;
        if (timerElement) timerElement.textContent = timeLeft.toString();
        if (closeTimer) closeTimer.textContent = timeLeft.toString();

        if (timeLeft <= 0) {
          clearInterval(interval);
          
          // Enable close button
          if (closeBtn) {
            closeBtn.disabled = false;
            closeBtn.className = 'w-full bg-green-500 text-white py-2 px-4 rounded-lg font-medium hover:bg-green-600 cursor-pointer';
            closeBtn.innerHTML = '✓ Claim Reward & Close';
            
            closeBtn.onclick = () => {
              document.body.removeChild(adOverlay);
              resolve(true); // User watched complete ad
            };
          }
        }
      }, 1000);

      // Allow early dismissal (but no reward)
      adOverlay.onclick = (e) => {
        if (e.target === adOverlay && timeLeft > 0) {
          clearInterval(interval);
          document.body.removeChild(adOverlay);
          resolve(false); // User dismissed early
        }
      };
    });
  }

  async showRewardedAd(): Promise<boolean> {
    // Use mock ad on web platform
    if (!Capacitor.isNativePlatform()) {
      console.log('Showing mock ad for web platform');
      return this.showMockAd();
    }

    try {
      // Ensure AdMob is initialized
      await this.initialize();

      const options: RewardedAdOptions = {
        adId: 'ca-app-pub-8905932082438698/6599032471', // Your rewarded ad unit ID
        isTesting: true, // Set to false in production
      };

      return new Promise((resolve, reject) => {
        // Set up listeners before showing the ad
        const rewardedListener = AdMob.addListener('onRewarded', (reward: AdReward) => {
          console.log('User earned reward:', reward);
          rewardedListener.remove();
          resolve(true);
        });

        const dismissedListener = AdMob.addListener('onRewardedVideoAdDismissed', () => {
          console.log('Rewarded ad dismissed without reward');
          dismissedListener.remove();
          resolve(false);
        });

        const failedListener = AdMob.addListener('onRewardedVideoAdFailedToLoad', (error: any) => {
          console.error('Rewarded ad failed to load:', error);
          failedListener.remove();
          reject(new Error('Ad failed to load'));
        });

        // Show the rewarded ad
        AdMob.showRewardedVideoAd(options).catch((error) => {
          console.error('Error showing rewarded ad:', error);
          rewardedListener.remove();
          dismissedListener.remove();
          failedListener.remove();
          reject(error);
        });
      });
    } catch (error) {
      console.error('Error in showRewardedAd:', error);
      throw error;
    }
  }

  async preloadRewardedAd(): Promise<void> {
    // Skip preloading on web platform (mock ads don't need preloading)
    if (!Capacitor.isNativePlatform()) {
      console.log('Mock ads ready for web platform');
      return;
    }

    try {
      await this.initialize();
      
      const options: RewardedAdOptions = {
        adId: 'ca-app-pub-8905932082438698/6599032471',
        isTesting: true,
      };

      await AdMob.prepareRewardedVideoAd(options);
      console.log('Rewarded ad preloaded successfully');
    } catch (error) {
      console.error('Failed to preload rewarded ad:', error);
    }
  }
}

export const adMobService = AdMobService.getInstance();