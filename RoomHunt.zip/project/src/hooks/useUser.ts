// src/hooks/useUser.ts

import { useState, useEffect } from "react";

// Define a type for user data
type User = {
  id: string;
  email: string;
};

export const useUser = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);

  useEffect(() => {
    // Simulate a logged-in user (replace this with real auth logic)
    const fakeUser = {
      id: "user_123456",
      email: "user@example.com",
    };

    setCurrentUser(fakeUser);
  }, []);

  return { currentUser };
};
