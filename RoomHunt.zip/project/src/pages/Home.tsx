import React, { useState } from 'react';
import Hero from '../components/Home/Hero';
import SearchFilters from '../components/Home/SearchFilters';
import PropertyList from '../components/Home/PropertyList';
import PopularAreas from '../components/Home/PopularAreas';

const Home: React.FC = () => {
  const [searchFilters, setSearchFilters] = useState({});

  const handleSearch = (filters: any) => {
    setSearchFilters(filters);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Hero />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <SearchFilters onSearch={handleSearch} />
        <PropertyList filters={searchFilters} />
      </div>

      <PopularAreas />
    </div>
  );
};

export default Home;