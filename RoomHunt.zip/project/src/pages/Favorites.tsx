import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import PropertyCard from '../components/Property/PropertyCard';
import { useFavorites } from '../contexts/FavoritesContext';
import { useAuth } from '../contexts/AuthContext';
import { motion } from 'framer-motion';
import { Heart, Loader2, ArrowLeft, Play, Gift } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { adMobService } from '../lib/admob';

interface Property {
  id: string;
  title: string;
  rent: number;
  location: string;
  image_url: string | null;
  owner_id: string;
  owner_name: string;
  owner_phone: string;
  is_premium: boolean | null;
  created_at: string | null;
  payment_status: string | null;
  payment_id: string | null;
}

const Favorites: React.FC = () => {
  const [favoriteProperties, setFavoriteProperties] = useState<Property[]>([]);
  const [loading, setLoading] = useState(true);
  const [showContactModal, setShowContactModal] = useState(false);
  const [selectedProperty, setSelectedProperty] = useState<Property | null>(null);
  const [adLoading, setAdLoading] = useState(false);
  const [adError, setAdError] = useState<string | null>(null);
  
  const { favorites } = useFavorites();
  const { currentUser, isPremium, updatePremiumStatus } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (currentUser && favorites.length > 0) {
      fetchFavoriteProperties();
    } else {
      setFavoriteProperties([]);
      setLoading(false);
    }
  }, [favorites, currentUser]);

  const fetchFavoriteProperties = async () => {
    if (favorites.length === 0) {
      setFavoriteProperties([]);
      setLoading(false);
      return;
    }

    try {
      const { data, error } = await supabase
        .from('rooms')
        .select('*')
        .in('id', favorites);

      if (error) throw error;
      
      setFavoriteProperties(data || []);
    } catch (error) {
      console.error('Error fetching favorite properties:', error);
      setFavoriteProperties([]);
    } finally {
      setLoading(false);
    }
  };

  const handleViewContact = (property: Property) => {
    setSelectedProperty(property);
    setShowContactModal(true);
    setAdError(null);
  };

  const handleWatchAd = async () => {
    if (!currentUser) {
      alert('Please login to view contact details');
      return;
    }

    setAdLoading(true);
    setAdError(null);

    try {
      const adWatched = await adMobService.showRewardedAd();
      
      if (adWatched) {
        // Update premium status in database
        await updatePremiumStatus(true);
        
        // Show success message
        const successMessage = document.createElement('div');
        successMessage.className = 'fixed top-4 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50';
        successMessage.textContent = '🎉 Contact unlocked! You now have premium access.';
        document.body.appendChild(successMessage);
        
        setTimeout(() => {
          document.body.removeChild(successMessage);
        }, 3000);
      } else {
        setAdError('Please watch the complete ad to unlock contact details.');
      }
    } catch (error) {
      console.error('Error showing ad:', error);
      setAdError('Ad not available now. Try again later.');
    } finally {
      setAdLoading(false);
    }
  };

  if (!currentUser) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-xl shadow-lg p-8 text-center max-w-md w-full"
        >
          <Heart size={64} className="mx-auto text-gray-400 mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Please Login</h2>
          <p className="text-gray-600 mb-6">You need to login to view your favorites</p>
          <button
            onClick={() => navigate('/login')}
            className="bg-teal-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-teal-700 transition-colors"
          >
            Login Now
          </button>
        </motion.div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="flex items-center justify-center py-12">
          <Loader2 size={32} className="animate-spin text-teal-600" />
          <span className="ml-2 text-gray-600">Loading favorites...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center mb-4">
            <button
              onClick={() => navigate('/')}
              className="p-2 rounded-lg hover:bg-gray-100 transition-colors mr-2"
            >
              <ArrowLeft size={20} />
            </button>
            <h1 className="text-3xl font-bold text-gray-900 flex items-center">
              <Heart size={32} className="mr-3 text-red-500" />
              My Favorites
            </h1>
          </div>
          <p className="text-gray-600">
            {favoriteProperties.length} favorite {favoriteProperties.length === 1 ? 'property' : 'properties'}
          </p>
        </motion.div>

        {favoriteProperties.length === 0 ? (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center py-12"
          >
            <Heart size={64} className="mx-auto text-gray-400 mb-4" />
            <h3 className="text-xl font-semibold text-gray-900 mb-2">No Favorites Yet</h3>
            <p className="text-gray-600 mb-6">
              Start adding properties to your favorites by clicking the heart icon on any property card.
            </p>
            <button
              onClick={() => navigate('/')}
              className="bg-teal-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-teal-700 transition-colors"
            >
              Browse Properties
            </button>
          </motion.div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {favoriteProperties.map((property, index) => (
              <motion.div
                key={property.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <PropertyCard
                  property={property}
                  onViewContact={handleViewContact}
                />
              </motion.div>
            ))}
          </div>
        )}

        {/* Contact Modal */}
        {showContactModal && selectedProperty && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-white rounded-xl p-6 max-w-md w-full"
            >
              <h3 className="text-xl font-bold text-gray-900 mb-4">Contact Owner</h3>
              
              {isPremium ? (
                <div className="space-y-4">
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                    <div className="flex items-center mb-2">
                      <Gift className="text-green-600 mr-2" size={20} />
                      <p className="text-green-800 font-medium">Premium Access Active</p>
                    </div>
                    <p className="text-gray-900 mt-2">
                      <strong>Name:</strong> {selectedProperty.owner_name}
                    </p>
                    <p className="text-gray-900">
                      <strong>Phone:</strong> {selectedProperty.owner_phone}
                    </p>
                  </div>
                  
                  <a
                    href={`tel:${selectedProperty.owner_phone}`}
                    className="w-full bg-teal-600 text-white py-3 px-4 rounded-lg font-medium hover:bg-teal-700 block text-center transition-colors"
                  >
                    📞 Call Now
                  </a>
                </div>
              ) : (
                <div className="text-center">
                  <div className="bg-gradient-to-r from-yellow-50 to-orange-50 border border-yellow-200 rounded-lg p-4 mb-4">
                    <div className="flex items-center justify-center mb-2">
                      <Play className="text-yellow-600 mr-2" size={20} />
                      <p className="text-yellow-800 font-medium">Premium Feature</p>
                    </div>
                    <p className="text-yellow-700 text-sm">
                      Watch a short ad to unlock owner contact details and get premium access!
                    </p>
                  </div>

                  {adError && (
                    <div className="bg-red-50 border border-red-200 rounded-lg p-3 mb-4">
                      <p className="text-red-600 text-sm">{adError}</p>
                    </div>
                  )}
                  
                  <button
                    onClick={handleWatchAd}
                    disabled={adLoading}
                    className="w-full bg-gradient-to-r from-green-500 to-green-600 text-white py-3 px-4 rounded-lg font-medium hover:from-green-600 hover:to-green-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center justify-center"
                  >
                    {adLoading ? (
                      <>
                        <Loader2 className="animate-spin mr-2" size={16} />
                        Loading Ad...
                      </>
                    ) : (
                      <>
                        <Play className="mr-2" size={16} />
                        Watch Ad & Unlock Contact
                      </>
                    )}
                  </button>

                  <p className="text-xs text-gray-500 mt-2">
                    Free • 30 seconds • Unlocks premium access
                  </p>
                </div>
              )}
              
              <button
                onClick={() => {
                  setShowContactModal(false);
                  setSelectedProperty(null);
                  setAdError(null);
                }}
                className="w-full mt-4 bg-gray-100 text-gray-700 py-2 px-4 rounded-lg font-medium hover:bg-gray-200 transition-colors"
              >
                Close
              </button>
            </motion.div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Favorites;