import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import PropertyCard from '../components/Property/PropertyCard';
import { Home, Users, Building2, List } from 'lucide-react';

interface Property {
  id: string;
  title: string;
  rent: number;
  location: string;
  image_url: string | null;
  image_urls: string[] | null;
  owner_id: string;
  owner_name: string;
  owner_phone: string;
  is_premium: boolean | null;
  created_at: string | null;
  payment_status: string | null;
  payment_id: string | null;
  property_type: string | null;
  description?: string;
  amenities?: string[];
}

const Accommodations: React.FC = () => {
  const [properties, setProperties] = useState<Property[]>([]);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchProperties();
  }, []);

  const fetchProperties = async () => {
    try {
      const { data, error } = await supabase.from('rooms').select('*');
      if (error) throw error;
      setProperties(data || []);
    } catch (error) {
      console.error('Error fetching properties:', error);
    } finally {
      setLoading(false);
    }
  };

  const lowerCaseIncludes = (text: string | undefined | null, keyword: string) =>
    text?.toLowerCase().includes(keyword.toLowerCase());

  const filterByCategory = (category: string) => {
    if (category === 'All') return properties;

    if (category === 'Private Rooms') {
      return properties.filter(p =>
        ['Rooms', 'shared room', 'studio', '1rk', '1bhk'].some(keyword =>
          lowerCaseIncludes(p.property_type, keyword) || lowerCaseIncludes(p.title, keyword)
        )
      );
    }

    if (category === 'PG Hostels') {
      return properties.filter(p =>
        ['PGs'].some(keyword =>
          lowerCaseIncludes(p.property_type, keyword) || lowerCaseIncludes(p.title, keyword)
        )
      );
    }

    if (category === 'Apartments') {
      return properties.filter(p =>
        ['apartment'].some(keyword =>
          lowerCaseIncludes(p.property_type, keyword) || lowerCaseIncludes(p.title, keyword)
        )
      );
    }

    return [];
  };

  const getCategoryCount = (category: string) => filterByCategory(category).length;

  const categories = [
    {
      name: 'All',
      icon: List,
      description: 'All available accommodations',
    },
    {
      name: 'Private Rooms',
      icon: Users,
      description: 'Individual rooms with shared or private bathrooms, perfect for students and working professionals.',
    },
    {
      name: 'PG Hostels',
      icon: Building2,
      description: 'Fully managed accommodations with meals, housekeeping, and a community living experience.',
    },
    {
      name: 'Apartments',
      icon: Home,
      description: 'Complete living spaces with kitchen, living room, and private amenities for independent living.',
    },
  ];

  const filteredProperties = filterByCategory(selectedCategory);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-teal-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading accommodations...</p>
        </div>
      </div>
    );
  }

  return (
    <section className="min-h-screen bg-gray-50 py-10 px-4">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl font-bold text-center mb-10">Rooms & Accommodations</h1>

        {/* Category Tabs */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-10">
          {categories.map(({ name, icon: Icon, description }) => (
            <div
              key={name}
              className={`border p-4 rounded-lg shadow-sm cursor-pointer transition ${
                selectedCategory === name ? 'bg-teal-100 border-teal-400' : 'hover:bg-gray-100'
              }`}
              onClick={() => setSelectedCategory(name)}
            >
              <div className="flex items-center gap-2 mb-2 text-lg font-semibold text-teal-800">
                <Icon size={20} />
                {name} ({getCategoryCount(name)} properties)
              </div>
              <p className="text-sm text-gray-600">{description}</p>
            </div>
          ))}
        </div>

        {/* Property Listings */}
        {filteredProperties.length === 0 ? (
          <p className="text-center text-gray-500">No properties found for selected category.</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProperties.map((property) => (
              <PropertyCard key={property.id} property={property} />
            ))}
          </div>
        )}
      </div>
    </section>
  );
};

export default Accommodations;
