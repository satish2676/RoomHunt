import React, { createContext, useContext, useEffect, useState } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase } from '../lib/supabase';

interface AuthContextType {
  currentUser: User | null;
  session: Session | null;
  userType: 'tenant' | 'owner' | null;
  isPremium: boolean | null;
  loading: boolean;
  signUp: (email: string, password: string, userData: any) => Promise<void>;
  signIn: (email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
  setUserType: (type: 'tenant' | 'owner') => void;
  updatePremiumStatus: (isPremium: boolean) => Promise<void>;
  refreshUserData: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [userType, setUserType] = useState<'tenant' | 'owner' | null>(null);
  const [isPremium, setIsPremium] = useState<boolean | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchUserProfile = async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('role, is_premium')
        .eq('id', userId)
        .single();

      if (error && error.code !== 'PGRST116') {
        console.error('Error fetching user profile:', error);
        return { role: null, is_premium: false };
      }

      return {
        role: data?.role || null,
        is_premium: data?.is_premium || false
      };
    } catch (error) {
      console.error('Error in fetchUserProfile:', error);
      return { role: null, is_premium: false };
    }
  };

  const refreshUserData = async () => {
    if (!currentUser) return;

    const profile = await fetchUserProfile(currentUser.id);
    setUserType(profile.role);
    setIsPremium(profile.is_premium);
    
    if (profile.role) {
      localStorage.setItem('userType', profile.role);
    }
  };

  useEffect(() => {
    // Get initial session
    supabase.auth.getSession().then(async ({ data: { session } }) => {
      setSession(session);
      setCurrentUser(session?.user ?? null);
      
      if (session?.user) {
        const profile = await fetchUserProfile(session.user.id);
        setUserType(profile.role);
        setIsPremium(profile.is_premium);
        
        if (profile.role) {
          localStorage.setItem('userType', profile.role);
        }
      }
      
      setLoading(false);
    });

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        setSession(session);
        setCurrentUser(session?.user ?? null);
        
        if (session?.user) {
          const profile = await fetchUserProfile(session.user.id);
          setUserType(profile.role);
          setIsPremium(profile.is_premium);
          
          if (profile.role) {
            localStorage.setItem('userType', profile.role);
          }
        } else {
          setUserType(null);
          setIsPremium(null);
          localStorage.removeItem('userType');
        }
        
        setLoading(false);
      }
    );

    return () => subscription.unsubscribe();
  }, []);

  const signUp = async (email: string, password: string, userData: any) => {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
    });

    if (error) throw error;

    if (data.user) {
      // Create profile
      const { error: profileError } = await supabase
        .from('profiles')
        .insert({
          id: data.user.id,
          email: email,
          role: userData.type,
          is_premium: false,
        });

      if (profileError) throw profileError;
    }
  };

  const signIn = async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) throw error;
  };

  const signOut = async () => {
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
    
    setUserType(null);
    setIsPremium(null);
    localStorage.removeItem('userType');
  };

  const handleSetUserType = (type: 'tenant' | 'owner') => {
    setUserType(type);
    localStorage.setItem('userType', type);
  };

  const updatePremiumStatus = async (newIsPremium: boolean) => {
    if (!currentUser) return;

    try {
      const { error } = await supabase
        .from('profiles')
        .update({ is_premium: newIsPremium })
        .eq('id', currentUser.id);

      if (error) throw error;

      setIsPremium(newIsPremium);
    } catch (error) {
      console.error('Error updating premium status:', error);
      throw error;
    }
  };

  const value = {
    currentUser,
    session,
    userType,
    isPremium,
    loading,
    signUp,
    signIn,
    signOut,
    setUserType: handleSetUserType,
    updatePremiumStatus,
    refreshUserData
  };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
};